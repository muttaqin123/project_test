

<?php $__env->startSection('container'); ?>

  <div class="container">
    <div class="search">
        <input type="search" name="search" id="search" placeholder="search" class="form-control mt-3">
    </div>
  </div>

    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><?php echo e($title_table); ?></h1>        
    </div>

    <?php if(session()->has('success')): ?>
      <div class="alert alert-success col-lg-10" role="alert"> 
      <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>

    <div class="table-responsive col-lg-10">      
      <a href="/tipe/create" class="btn btn-primary mb-2">Tambah Daftar Tipe Barang</a>
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col"><?php echo e($title_kolom); ?></th>              
              <th scope="col">Action</th>              
            </tr>
          </thead>
          <tbody class="alldata">
            <?php $__currentLoopData = $tipe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($tipe->id); ?></td>                    
                    <td><?php echo e($tipe->nama_tipe); ?></td>                    
                    <td>
                        <a href="/tipe/<?php echo e($tipe->id); ?>/edit" class="badge bg-warning"><span data-feather="edit"></span></a>
                        <form action="/tipe/<?php echo e($tipe->id); ?>" method="post" class="d-inline"> 
                          <?php echo method_field('delete'); ?>
                          <?php echo csrf_field(); ?>
                          <button class="badge bg-danger border-0" onclick="return confirm('Anda yakin akan menghapus data ini?')">
                            <span data-feather="x-circle"></span>
                          </button>
                        </form>
                    </td>                  
                </tr>     
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </tbody>

          <tbody id="Content" class="searchdata"></tbody>
        </table>
      </div>
    
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
      <script type="text/javascript">
        $('#search').on('keyup', function(){
          // alert('hello');
          $value=$(this).val();
          // console.log('tolo');
          if($value){
            $('.alldata').hide();
            $('.searchdata').show();
          }else{
            $('.alldata').show();
            $('.searchdata').hide();
          }
          
          $.ajax({          
            type : 'get',
            url : '<?php echo e(URL::to('searchh')); ?>',
            data:{'search':$value},
          
            success:function(data){
              // console.log(data);
              $('#Content').html(data);
            }
          });
      })
      </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\belajar-coding\laravel\project_test\resources\views/dashboard/menu/tipe.blade.php ENDPATH**/ ?>