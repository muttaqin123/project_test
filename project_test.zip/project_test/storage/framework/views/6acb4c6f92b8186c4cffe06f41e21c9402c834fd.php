

<?php $__env->startSection('container'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><?php echo e($title_table); ?></h1>        
    </div>

    <?php if(session()->has('success')): ?>
      <div class="alert alert-success col-lg-10" role="alert"> 
      <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>

    <div class="table-responsive col-lg-10">
      <?php if($title_table == 'Menu Barang'): ?>
      <a href="/barang/create" class="btn btn-primary mb-2">Tambah Data Barang</a>
      <?php elseif($title_table == 'Menu Jenis Barang'): ?>
      <a href="/jenis/create" class="btn btn-primary mb-2">Tambah Daftar Jenis Barang</a>
      <?php endif; ?>
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col"><?php echo e($title_kolom); ?></th>
              <?php if($title_table == 'Menu Barang'): ?>
                <th scope="col">Stok</th>
              <?php endif; ?>
              <th scope="col">Action</th>              
            </tr>
          </thead>
          <tbody>
            <?php if($title_table == 'Menu Barang'): ?>
            <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>                  
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($barang->nama_barang); ?></td>
                    <td><?php echo e($barang->stok); ?></td>
                    <td>
                        <a href="/barang/<?php echo e($barang->id); ?>/edit" class="badge bg-warning"><span data-feather="edit"></span></a>
                        <form action="/barang/<?php echo e($barang->id); ?>" method="post" class="d-inline"> 
                          <?php echo method_field('delete'); ?>
                          <?php echo csrf_field(); ?>
                          <button class="badge bg-danger border-0" onclick="return confirm('Anda yakin akan menghapus data ini?')">
                            <span data-feather="x-circle"></span>
                          </button>
                        </form>
                    </td>
                <tr>                  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            <?php elseif($title_table == 'Menu Jenis Barang'): ?>
            <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($loop->iteration); ?></td>                    
                    <td><?php echo e($jenis->nama_jenis); ?></td>                    
                    <td>
                        <a href="/jenis/<?php echo e($jenis->id); ?>/edit" class="badge bg-warning"><span data-feather="edit"></span></a>
                        <form action="/jenis/<?php echo e($jenis->id); ?>" method="post" class="d-inline"> 
                          <?php echo method_field('delete'); ?>
                          <?php echo csrf_field(); ?>
                          <button class="badge bg-danger border-0" onclick="return confirm('Anda yakin akan menghapus data ini?')">
                            <span data-feather="x-circle"></span>
                          </button>
                        </form>
                    </td>                  
                </tr>     
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\belajar-coding\laravel\project_test\resources\views/dashboard/menu/index.blade.php ENDPATH**/ ?>